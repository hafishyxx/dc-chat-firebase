// import functions of firebase for inicialition 
import { initializeApp } from "firebase/app";
import { getDatabase } from "firebase/database";
import { getStorage } from "firebase/storage";
import { getAuth } from "firebase/auth"

//Paste here your own firebaseConfig
const firebaseConfig = {

  apiKey: "AIzaSyBmrgJfJ_X2GLZhmrYu7VZlGy9F_aOiZp0",
  authDomain: "doyan-curhat.firebaseapp.com",
  projectId: "doyan-curhat",
  storageBucket: "doyan-curhat.appspot.com",
  messagingSenderId: "808378328174",
  appId: "1:808378328174:web:5a645959a70f293377b27f",
  databaseURL: "https://doyan-curhat-default-rtdb.asia-southeast1.firebasedatabase.app/",
  storageURL: "gs://doyan-curhat.appspot.com"
};

//inicialition function 
const app = initializeApp(firebaseConfig);
const rdb = getDatabase(app);
const sdb = getStorage(app)
const auth = getAuth(app);

export { rdb, sdb, auth }
export default app
