import React from 'react'
import "./Rights.css"

const Rights = () => {
    return (
        <div id="rights" >
            {/* <p>©2024 <a href="https://doyan-it.my.id/" target="_blank">Doyan IT</a>. All rights reserved.</p> */}
        </div>
    )
}

export default Rights
