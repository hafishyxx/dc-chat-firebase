import React from 'react'
import success from "../../../assets/auth/success.svg"

const SuccessForm = () => {
    return (
        <div id="success-form" >
           <img src={success} />  
        </div>
    )
}

export default SuccessForm
